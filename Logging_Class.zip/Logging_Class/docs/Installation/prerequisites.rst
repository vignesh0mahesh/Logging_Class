Prerequisites
+++++++++++++

Required Python Packages
========================
* python-logging-loki
* icecream
* ansicolors

.. tip:: 
    You can manually install the above packages using the pip command or you can use the requirements.txt file as the pip input and go from there.

    *After changing directory to the path where requirements.txt is in the terminal, run the following*
    ::
        
        pip install -r requirements.txt