Logging Function Usages
=======================


Debug Logging Function
++++++++++++++++++++++
This is the function to log a debug level message

.. autofunction:: Logging_Import.LogUpload.debug

Info Logging Function
++++++++++++++++++++++
This is the function to log a info level message

.. autofunction:: Logging_Import.LogUpload.info


Warning Logging Function
++++++++++++++++++++++++
This is the function to log a warning level message

.. autofunction:: Logging_Import.LogUpload.warning

Error Logging Function
++++++++++++++++++++++++
This is the function to log a error level message

.. autofunction:: Logging_Import.LogUpload.error

Critical Logging Function
++++++++++++++++++++++++++
This is the function to log a critical level message

.. autofunction:: Logging_Import.LogUpload.critical